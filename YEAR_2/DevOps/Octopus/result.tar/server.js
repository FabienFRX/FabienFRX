const express = require('express');
const { Pool } = require('pg');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const port = process.env.PORT || 5001;

app.use(express.static('public'));
app.set('view engine', 'ejs');

// DB configuration
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'postgres',
  password: process.env.DB_PASS || 'postgres',
  port: process.env.DB_PORT || 5432,
});

app.get('/', (req, res) => {
  res.render('index');
});

async function getVotes() {
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT vote, COUNT(id) AS count FROM votes GROUP BY vote');
    const results = {
      a: 0,
      b: 0
    };
    
    rows.forEach(row => {
      results[row.vote] = parseInt(row.count);
    });
    
    return results;
  } finally {
    client.release();
  }
}

io.on('connection', async (socket) => {
  console.log('Client connected');
  const votes = await getVotes();
  socket.emit('results', votes);
});

setInterval(async () => {
  const votes = await getVotes();
  io.emit('results', votes);
}, 1000);

server.listen(port, () => {
  console.log(`Result app listening at http://localhost:${port}`);
});
