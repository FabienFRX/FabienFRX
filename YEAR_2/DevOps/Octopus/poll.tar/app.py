from flask import Flask, request, render_template
import os
import redis

app = Flask(__name__)
redis_host = os.environ.get('REDIS_HOST', 'localhost')
redis_port = os.environ.get('REDIS_PORT', 6379)
redis_conn = redis.Redis(host=redis_host, port=redis_port)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        vote = request.form.get('vote')
        redis_conn.rpush('votes', vote)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
