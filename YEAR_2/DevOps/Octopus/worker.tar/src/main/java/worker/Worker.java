package worker;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;
import java.sql.*;
import java.util.Map;
import java.util.HashMap;

public class Worker {
    public static void main(String[] args) {
        try {
            Jedis redis = connectToRedis();
            Connection dbConn = connectToDB();

            System.err.println("Watching vote queue");
            while (true) {
                String voteJSON = redis.blpop(0, "votes").get(1);
                System.err.println("Got: " + voteJSON);
                
                String vote = voteJSON;
                updateVote(dbConn, vote);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    static Jedis connectToRedis() {
        String host = System.getenv("REDIS_HOST");
        if (host == null) {
            host = "localhost";
        }
        
        int port = 6379;
        if (System.getenv("REDIS_PORT") != null) {
            port = Integer.parseInt(System.getenv("REDIS_PORT"));
        }

        Jedis conn = new Jedis(host, port);

        while (true) {
            try {
                conn.ping();
                break;
            } catch (JedisConnectionException e) {
                System.err.println("Waiting for redis");
                sleep(1000);
            }
        }

        System.err.println("Connected to redis");
        return conn;
    }

    static Connection connectToDB() throws SQLException {
        String host = System.getenv("DB_HOST");
        String port = System.getenv("DB_PORT");
        String user = System.getenv("DB_USER");
        String password = System.getenv("DB_PASS");
        String name = System.getenv("DB_NAME");

        if (host == null) host = "localhost";
        if (port == null) port = "5432";
        if (user == null) user = "postgres";
        if (password == null) password = "postgres";
        if (name == null) name = "postgres";

        String url = "jdbc:postgresql://" + host + ":" + port + "/" + name;

        while (true) {
            try {
                Connection conn = DriverManager.getConnection(url, user, password);
                System.err.println("Connected to db");
                return conn;
            } catch (SQLException e) {
                System.err.println("Waiting for db");
                sleep(1000);
            }
        }
    }

    static void updateVote(Connection dbConn, String vote) throws SQLException {
        PreparedStatement insert = dbConn.prepareStatement(
            "INSERT INTO votes (id, vote) VALUES (?, ?)");
        insert.setString(1, String.valueOf(System.currentTimeMillis()));
        insert.setString(2, vote);
        insert.execute();
    }

    static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            System.exit(1);
        }
    }
}
